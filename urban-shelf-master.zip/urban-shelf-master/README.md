# urban-shelf
A urban shelf é uma plataforma de gestão de bibliotecas de rua com uma vertente social, no sentido em que promove a avaliação e troca de comentários sobre os livros disponiveis para requesição, os quais são doados por operadores da plataforma.
Na urban shelf pode pesquisar, requesitar, e avaliar, mas não só! Com o seu sistema de localização de bibliotecas, através do acesso à sua localização atual conseguimos propor-lhe as mais próximas, ou simplesmente proporiconar-lhe a informação de qualquer uma destas.

Um manual de utilizador será aqui exposto após a fase de testes.

Esta plataforma está a ser desenvolvida no ambito da disciplina de Projeto 1, Tecnologias e Sistemas de Informação para a Web- 1º ano, da Escola Superior de Media Artes e Design.
